//
//  OrderDataModel.swift
//  clothing-app
//
//  Created by Sajana Rupasinghe on 2024-03-30.
//

import Foundation

struct OrderDataModel : Codable {
    var email : String
    var total : String
}
