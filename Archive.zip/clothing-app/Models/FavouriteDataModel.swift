//
//  FavouriteDataModel.swift
//  clothing-app
//
//  Created by Sajana Rupasinghe on 2024-03-29.
//

import Foundation

struct FavouriteDataModel : Codable {
    var item_id : String
    var user_id : String
}
