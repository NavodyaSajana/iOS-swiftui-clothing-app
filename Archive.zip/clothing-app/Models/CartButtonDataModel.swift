//
//  CartButtonDataModel.swift
//  clothing-app
//
//  Created by Sajana Rupasinghe on 2024-03-30.
//

import Foundation

struct CartButtonDataModel : Codable {
    var item_count : Int
}
