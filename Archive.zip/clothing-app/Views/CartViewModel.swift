//
//  CartViewModel.swift
//  clothing-app
//
//  Created by Sajana Rupasinghe on 2024-03-21.
//

import Foundation
import SwiftUI

class CartViewModel : ObservableObject {
    @Published var errorMessage: String = ""
    @Published var items: [CartDataModel] = []
    @Published var total : Double = 0.00
    
    func fetchCartData(forEmail email: String) {
        guard let url = URL(string: "http://localhost:3000/api/cart/\(email)") else {
            self.errorMessage = "Invalid URL"
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                self.errorMessage = error?.localizedDescription ?? "Unknown error"
                return
            }
            
            do {
                let decodedData = try JSONDecoder().decode([CartDataModel].self, from: data)
                DispatchQueue.main.async {
                    self.items = decodedData
                }
            } catch {
                self.errorMessage = error.localizedDescription
            }
        }.resume()
    }
}
