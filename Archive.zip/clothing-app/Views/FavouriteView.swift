//
//  FavouriteView.swift
//  clothing-app
//
//  Created by Sajana Rupasinghe on 2024-03-25.
//

import SwiftUI

struct FavouriteView: View {
    
    @StateObject var userVM : UserViewModel = UserViewModel()
    //@State var favVM : FavouriteViewModel = FavouriteViewModel()
    @StateObject var viewModel = FavouriteViewModel()
    
    var body: some View {
        
        List{
            if userVM.authenticated {
                if viewModel.products.count < 0{
                    Text("Your favourites is Empty!")
                }else {
                    ForEach(viewModel.products){
                        data in
                        FavouriteItemCard(itemDM: data)
                    }
                }
            } else {
                Text("Login to check your Favouries!")
            }
        }
        .onAppear{
            if userVM.authenticated{
                viewModel.fetchFavouriteItems(forEmail: userVM.username)
            }
        }
    }
}

#Preview {
    FavouriteView()
}
