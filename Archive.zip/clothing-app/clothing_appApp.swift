//
//  clothing_appApp.swift
//  clothing-app
//
//  Created by Sajana Rupasinghe on 2024-03-13.
//

import SwiftUI

@main
struct clothing_appApp: App {
    var body: some Scene {
        WindowGroup {
            DashboardView()
        }
    }
}
